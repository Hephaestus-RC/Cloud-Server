#pragma once

#include<stdio.h>

int add(int x,int y);
